=== Concatenador de Contenido Semanal ===
Contributors: vozcatolica
Tags: series, contenido semanal, cursos, posts
Requires at least: 6.0
Requires PHP: 7.4
Tested up to: 6.8
Stable tag: 1.1.0
License: GPLv2 or later

Organiza entregas semanales dentro de posts normales y devuelve el post al inicio cuando publicas una entrega nueva.

== Descripción ==

Este plugin no crea ni reemplaza el tipo de contenido "post". Añade un panel de Entregas semanales al editor normal.

Cada entrega tiene:

* Título
* Fecha
* Estado borrador o publicada
* Contenido compatible con HTML permitido y shortcodes

Al guardar una entrega nueva como publicada dentro de un post ya publicado, el plugin actualiza la fecha del post. De esta forma, el post vuelve a aparecer como el más reciente en listados ordenados por fecha.

== Instalación ==

1. Copia la carpeta `weekly-content-concatenator` dentro de `/wp-content/plugins/`.
2. Activa "Concatenador de Contenido Semanal" desde Plugins.
3. Abre o crea un post normal.
4. Usa el panel "Entregas semanales" situado debajo del editor.
5. Marca "Mostrar las entregas automáticamente al final de este post".
6. Añade una entrega, cambia su estado a "Publicada" y actualiza el post.

== Uso ==

Por defecto, las entregas publicadas se muestran automáticamente al final del post en un moderno formato de acordeón accesible y móvil-friendly, junto con un índice colapsable enlazado.

Para controlar manualmente dónde aparecen, desmarca la visualización automática e inserta este shortcode en el contenido:

[contenido_semanal]

También puedes mostrar las entregas de otro post indicando su ID:

[contenido_semanal id="123"]

== Comportamiento de la fecha ==

El post solo vuelve al inicio cuando detecta por primera vez una entrega con estado "Publicada". Editar una entrega ya publicada no vuelve a modificar la fecha del post.

== Novedades de la versión 1.1.0 ==

* **Visualización en Acordeón**: Se reemplazó el listado largo de entregas por un acordeón interactivo y accesible (`<details>` y `<summary>` nativos).
* **Diseño Mobile-First**: Estilos adaptados para dispositivos móviles y zonas táctiles de al menos 52px.
* **Mejoras en Panel de Admin**: Se colapsan las entregas de forma automática para trabajar mejor, e incluye badges de estado y fecha legibles de un vistazo.

